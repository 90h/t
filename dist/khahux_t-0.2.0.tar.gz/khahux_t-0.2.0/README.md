# khahux_t

    pip install git+https://github.com/90h/t

    khahux_t word
